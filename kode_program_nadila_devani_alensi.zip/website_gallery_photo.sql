-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Waktu pembuatan: 22 Feb 2024 pada 04.48
-- Versi server: 8.0.30
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `website_gallery_photo`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `album`
--

CREATE TABLE `album` (
  `AlbumID` int NOT NULL,
  `NamaAlbum` varchar(225) NOT NULL,
  `Deskripsi` text NOT NULL,
  `TanggalDibuat` date NOT NULL,
  `UserID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data untuk tabel `album`
--

INSERT INTO `album` (`AlbumID`, `NamaAlbum`, `Deskripsi`, `TanggalDibuat`, `UserID`) VALUES
(1, 'Seni Pixel', 'Karya luar biasa dari pelukis digital seluruh dunia', '2024-02-20', 1),
(2, 'Arsitektur', 'Inspirasi desain rumah, bangunan dari berbagai arsitek di dunia', '2024-02-20', 1),
(5, 'Bunga', 'potret bunga nan indah yg dapat dilihat disini', '2024-02-20', 2),
(6, 'Biru', 'Semua hal yang berwarna biru, karna biru itu mahal', '2024-02-20', 1),
(7, 'Animals', 'Kumpulan hewan lucu yg menggemaskan', '2024-02-20', 1),
(10, 'ss', 'coba ukk', '2024-02-22', 6);

-- --------------------------------------------------------

--
-- Struktur dari tabel `foto`
--

CREATE TABLE `foto` (
  `FotoID` int NOT NULL,
  `JudulFoto` varchar(225) NOT NULL,
  `DeskripsiFoto` text NOT NULL,
  `TanggalUnggah` date NOT NULL,
  `LokasiFile` varchar(225) NOT NULL,
  `AlbumID` int NOT NULL,
  `UserID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data untuk tabel `foto`
--

INSERT INTO `foto` (`FotoID`, `JudulFoto`, `DeskripsiFoto`, `TanggalUnggah`, `LokasiFile`, `AlbumID`, `UserID`) VALUES
(2, 'galeri art', 'sebuah galeri seni di manila', '2024-02-20', 'public/storage/gz08NfXolX1LklobdX3MvqyJAfxsE0BSJnCXRasy.jpg', 1, 1),
(3, 'Bunga Matahari', 'Sekuntung bunga matahari yg berdiri kokoh', '2024-02-20', 'public/unggahan/pfz5nXye9ECZly1UNE6IydhCoJad57aGyuRvB9Sg.jpg', 5, 2),
(4, 'Pink Tulip On Sunset', 'Fotografi indah dengan objek bunga tulip berwarna pink', '2024-02-20', 'public/unggahan/aWIWL5E50tNCWBt3sPWrMJO4L5vMilASUytRcsnE.jpg', 5, 2),
(6, 'Buket Bunga', 'Foto buket bunga yg dijual dipinggir jalan', '2024-02-20', 'public/unggahan/wE7OGxGhqCtd7UpzASHF8HzdUXvhGiLKIFoW5kD6.jpg', 5, 2),
(7, 'Dahlia Merah Muda', 'Dahlia merah muda atau pink dahlia merupakan bunga yg langkah dan hanya tumbuh di daerah pegunungan syrian', '2024-02-20', 'public/unggahan/OMtK7vFBAMyq6sZkyH8nuSvSNSN3Ll30R5P7oclM.jpg', 5, 2),
(8, 'Kanopi Futuristik', 'Inspirasi desain kanopi halaman yg desainnya futuristik', '2024-02-20', 'public/unggahan/Ok65HGLpGIorhNq0X93XrVpOT4UpJ7REgs3LeRoR.jpg', 2, 1),
(9, 'Citraland', 'Citraland merupakan komplek perumahan yg indah nan minimalis', '2024-02-20', 'public/unggahan/sX5CxjQKntGSbZonTKomcOS3iiWMjLna8t5C9eRm.jpg', 2, 1),
(10, 'Desain Minimalis & Elegan', 'desain yg minimalis dan elegan sangat tepat untuk rumah impian', '2024-02-20', 'public/unggahan/hsA1Z65xwuMNkxceGlsVqg4bKOvWRT05wRYDpGkr.jpg', 2, 1),
(11, 'Blue Sea', 'Warna biru di kedalaman lautan dan disertai ikan yg menari bebas', '2024-02-20', 'public/unggahan/GvdlEVje0PvjoDgBUAuRyHyb31j7utCPa3pcnUwv.jpg', 6, 1),
(12, 'Sanassatan', 'Apa itu? Piringan berwarna biru? wow menakjubkan bukan!', '2024-02-20', 'public/unggahan/eMb10we7d9L52yUXMcIVPASxVzbiHPjUxJvQwfnV.jpg', 6, 1),
(13, 'Cat Biru', 'Biru merupakan warna yg sulit didapat dan harganya mahal', '2024-02-20', 'public/unggahan/hULPXWaTRvJKmHxw7qYC4ZwVPsKZtTmwhfj45HYH.jpg', 6, 1),
(14, 'Headset Simile', 'headset berkualitas premium dengan pilihan warna menarik', '2024-02-20', 'public/unggahan/FlvZjlqwsCMJIWNMXpmhaG5B35PrdXSOekZjvm3E.jpg', 6, 1),
(15, 'Organisasi Sekolah', 'OSIS merupakan alternatif efektif untuk meningkatkan jiwa organisasi', '2024-02-20', 'public/unggahan/IS1yuEcBkHwHXwTlJ5Ey8cxSqQmmdR92y1jDBWb8.jpg', 8, 1),
(16, 'Masa Indah', 'Kata orang masa SMA adalah masa yg paling indah', '2024-02-20', 'public/unggahan/m7MEy7Fj4de4kuMFwv5ZH1kauJdt8YME16ZEkp4v.jpg', 8, 1),
(18, 'oimi', 'coba coba', '2024-02-22', 'public/unggahan/4PZWD3s7vfvPc1kRPUOUzyeVAzgST4o6D2i01pZT.jpg', 10, 6);

-- --------------------------------------------------------

--
-- Struktur dari tabel `komentarfoto`
--

CREATE TABLE `komentarfoto` (
  `KomentarID` int NOT NULL,
  `FotoID` int NOT NULL,
  `UserID` int NOT NULL,
  `IsiKomentar` text NOT NULL,
  `TanggalKomentar` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data untuk tabel `komentarfoto`
--

INSERT INTO `komentarfoto` (`KomentarID`, `FotoID`, `UserID`, `IsiKomentar`, `TanggalKomentar`) VALUES
(1, 1, 1, 'Kerennnnn', '2024-02-20'),
(2, 3, 1, 'cantik', '2024-02-22'),
(3, 2, 1, 'hebat!!', '2024-02-22');

-- --------------------------------------------------------

--
-- Struktur dari tabel `likefoto`
--

CREATE TABLE `likefoto` (
  `LikeID` int NOT NULL,
  `FotoID` int NOT NULL,
  `UserID` int NOT NULL,
  `TanggalLike` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data untuk tabel `likefoto`
--

INSERT INTO `likefoto` (`LikeID`, `FotoID`, `UserID`, `TanggalLike`) VALUES
(4, 1, 1, '2024-02-20'),
(6, 2, 1, '2024-02-22'),
(8, 3, 1, '2024-02-22'),
(9, 4, 1, '2024-02-22');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `UserID` int NOT NULL,
  `Username` varchar(225) NOT NULL,
  `Password` varchar(225) NOT NULL,
  `Email` varchar(225) NOT NULL,
  `NamaLengkap` varchar(225) NOT NULL,
  `Alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`UserID`, `Username`, `Password`, `Email`, `NamaLengkap`, `Alamat`) VALUES
(1, 'Nadila', '123', '10547@smkbukitasam.sch.id', 'nadila devani alensi', 'btn karang asam'),
(2, 'TES', '098', '10547@smkbukitasam.sch.id', 'nadila devani alensi', 'btn'),
(4, 'coba', '1', '10547@smkbukitasam.sch.id', 'nadila devani alensi', 'BTN. Karang Asam Jl. Anggrek, rt.02 rw.02, Tanjung Enim Selatan, Lawang Kidul'),
(5, 'coba', '1', '10547@smkbukitasam.sch.id', 'nadila devani alensi', 'BTN. Karang Asam Jl. Anggrek, rt.02 rw.02, Tanjung Enim Selatan, Lawang Kidul'),
(6, 'cek', '12345', 'nadilastevanialensi@gmail.com', 'nadila devani alensi', 'jl parigi');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `album`
--
ALTER TABLE `album`
  ADD PRIMARY KEY (`AlbumID`),
  ADD KEY `UserID` (`UserID`);

--
-- Indeks untuk tabel `foto`
--
ALTER TABLE `foto`
  ADD PRIMARY KEY (`FotoID`),
  ADD KEY `AlbumID` (`AlbumID`,`UserID`);

--
-- Indeks untuk tabel `komentarfoto`
--
ALTER TABLE `komentarfoto`
  ADD PRIMARY KEY (`KomentarID`),
  ADD KEY `FotoID` (`FotoID`,`UserID`);

--
-- Indeks untuk tabel `likefoto`
--
ALTER TABLE `likefoto`
  ADD PRIMARY KEY (`LikeID`),
  ADD KEY `FotoID` (`FotoID`,`UserID`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`UserID`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `album`
--
ALTER TABLE `album`
  MODIFY `AlbumID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT untuk tabel `foto`
--
ALTER TABLE `foto`
  MODIFY `FotoID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT untuk tabel `komentarfoto`
--
ALTER TABLE `komentarfoto`
  MODIFY `KomentarID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `likefoto`
--
ALTER TABLE `likefoto`
  MODIFY `LikeID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `UserID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
