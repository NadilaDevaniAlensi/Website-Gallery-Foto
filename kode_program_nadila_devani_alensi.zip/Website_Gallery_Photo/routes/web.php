<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\GalleryController;
use App\Models\Album;
use App\Models\Foto;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/


// route utama
Route::get('/', function () {
    return view('welcome');
});
Route::get('/regist', function () {
    return view('regist');
});
Route::get('/login', function () {
    return view('login');
});
Route::get('/home', function () {
    return view('home');
});
Route::get('/buatalbum', function () {
    return view('buatalbum');
});
Route::get('viewalbum', function () {
    return view('viewalbum');
});
Route::get('/uploadFoto', function () {
    return view('tambahfoto');
});


Route::get('/tambahfoto', function () {
    $album = Album::where('UserID', session('user')->UserID)->get();
    return view('tambahfoto', compact('album'));
});

// membuat & melihat album
Route::get('/album', function ()  {
    $albums = Album::all();
    return view('web.koleksi', compact('album'));
});



// regist
Route::get('/register',[UserController::class, 'tampilregist']);
Route::post('/register',[UserController::class, 'simpanregist']);
 
// login
Route::get('/login', [UserController::class, 'tampillogin']);
Route::post('/login',[UserController::class, 'simpanlogin']);

// home
Route::get('/home', [GalleryController::class, 'varhome']);

//buatalbum
Route::get('/buatalbum', [GalleryController::class, 'album']);
Route::post('/album' ,[GalleryController::class, 'buatAlbum']);
Route::get('/viewalbum', [GalleryController::class, 'viewAlbum']);

//foto
Route::get('/viewfoto/{AlbumID}', [GalleryController::class, 'viewfotoo']);
Route::get('/uploadFoto', [GalleryController::class, 'unggah']);
Route::post('/fotoAksiCoyyy', [GalleryController::class, 'unggahFoto']);

// like
Route::get('/likee/{FotoID}', [GalleryController::class, 'suka']);

//komen
Route::get('/komene/{FotoID}', [GalleryController::class, 'komen']);
Route::post('/berikomen/{FotoID}', [GalleryController::class, 'komene']);

//hapus foto & album
Route::delete('/hapusFoto/{FotoID}', [GalleryController::class, 'hapusFoto'])->name('hapusFoto');
Route::delete('/hapusAlbum/{AlbumID}', [GalleryController::class, 'hapusAlbum'])->name('hapusAlbum');

// logout
Route::get('/logout', [UserController::class, 'logout']); 