<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;

class UserController extends Controller
{
    // REGISTRASI
    public function tampilregist () {
        return view('regist');
    }

    public function simpanregist (Request $request) {
        // input data regist
        $data = new User();
        $data->Username = $request->input('Username');
        $data->Password = $request->input('Password');
        $data->Email = $request->input('Email');
        $data->NamaLengkap = $request->input('NamaLengkap');
        $data->Alamat = $request->input('Alamat');
        $data->save();

        // tampilan setelah berhasil dan pesannya
        return redirect('/login')->with('berhasil', 'Data telah tersimpan!');
    }

    // LOGIN
    public function tampillogin () {
        return view('login');
    }

    public function simpanlogin (Request $request) {
        // input data login
        $data = User::where('Username',$request->input('Username'))
        ->where('Password',$request->input('Password'))
        ->first();
        // pesan dan aksi selanjutnya
        if($data === null) {
            return redirect('/login')->with('pesan', 'Username atau Password salah!');

        }   
        else {
             session()->put('user', $data);
            return redirect('/home');
        }
    }

    // aksi logout
    public function logout() {
        session()->flush();
        return redirect('/login');
    }
}
