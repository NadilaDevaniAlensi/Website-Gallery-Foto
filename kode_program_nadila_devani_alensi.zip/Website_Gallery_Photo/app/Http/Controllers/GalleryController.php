<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Models\Album;
use App\Models\Foto;
use App\Models\LIke;
use App\Models\Komentar;

class GalleryController extends Controller
{
    
    public function varhome()
    {
        $album = Album::all();
        $foto = Foto::all();
        $likee = Like::all();
    return view('home', compact('album', 'foto', 'likee'));
    }

    public function album () {
        if(session('user') !=null) {
            return view('buatalbum');
        } else {
            return redirect('/login')->with('pesanbaru', 'Silahkan login terlebih dahulu!');
        }
    }

    public function buatalbum (Request $request) {
        $data = new Album ();
        $data->NamaAlbum = $request->input('NamaAlbum');
        $data->Deskripsi = $request->input('Deskripsi');
        $data->TanggalDibuat = Carbon::now();
        $data->UserID = session('user')->UserID;

        $data->save();

        return redirect('viewalbum');
    }

    public function viewAlbum() {
        if(session('user') !=null) {
            $album = Album::all();
            return view('viewalbum', ['album' => $album]); //salahnya disini guyss, seharusnya albums bukan album aja
        }
        else {
            return redirect('/login')->with('pesanbaru', 'Silahkan login terlebih dahulu');
        }
    }

    public function viewfotoo($AlbumID){
        $foto = Foto::where('AlbumID', $AlbumID)->get();
        $likee = Like::all();
        return view('viewfoto', compact('foto', 'likee'));
    }

    // FOTOOOO
    public function index() {
        $foto = Foto::all();
        $like = Like::all();
        return view('home', compact('foto')); //menyesuaikan variabel
    }
       
        //tambah foto
    public function unggah() {
        $album = Album::where('UserID', session('user')->UserID)->get();
        return view('tambahfoto', compact('album'));
    }
    
    public function unggahFoto(Request $request){
        if ($request->hasFile('LokasiFile')) {
            $locate = $request->file('LokasiFile')->store('public/unggahan');

            $data = new Foto();
            $data->JudulFoto = $request->input('JudulFoto');
            $data->DeskripsiFoto = $request->input('DeskripsiFoto');
            $data->TanggalUnggah = date('Y-m-d');
            $data->LokasiFile = $locate;
            $data->AlbumID = $request->get('album');
            $data->UserID = session('user')->UserID;
    
            $data->save();
            return redirect('/viewalbum')->with('sukses', 'foto berhasil');
        } else {
            echo "foto tidak terkirim";
        }
    }
    
    public function tampilFoto($AlbumID){
        if(session('user') != null) {
            $foto = Foto::where('AlbumID', $AlbumID)->get();
            $likee = Like::all();
            return view('viewfoto', compact('foto', 'like'));
            // dd($album);
        } else {
            return redirect('/login')->with('warning', 'Silahkan Login Terlebih Dahulu!');
        }
    }


    // LIKE
    public function suka($FotoID) {
        $cek = Like::where('UserID', session('user')->UserID)->where('FotoID', $FotoID)->first();
    
        if ($cek===null) {
            //kalo datanya kosong dia memberi like, kalo datanya sudah ada dia dislike
            $data = new Like;
            $data->FotoID = $FotoID;
            $data->UserID = session('user')->UserID;
            $data->TanggalLike = Carbon::now();
            $data->save();
            return redirect()->back();
        } else {
            $cek->delete();
            return redirect()->back();
        }
    }

    //komentar
    public function komen (Request $request, $FotoID) {
        $foto = Foto::find($FotoID);
        $likee = Like::all();
        $komen = Komentar::where('FotoID', $FotoID)->get();
        return view('komen', compact('foto', 'likee', 'komen'));
    }

    public function  komene (Request $request, $FotoID) {
        $data = new Komentar;
        $data->FotoID = $FotoID;
        $data->UserID = session('user')->UserID;
        $data->IsiKomentar = $request->input('isi');
        $data->TanggalKomentar = Carbon::now();

        $data->save();
        return redirect()->back();
    }

    public function hapusFoto($FotoID)
    {
        $foto = Foto::find($FotoID);

        // Hapus record foto dari database
        $foto->delete();

        return redirect()->back();
    }

    public function hapusAlbum($AlbumID)
    {
        $album = Album::find($AlbumID);

        // Hapus record foto dari database
        $album->delete();

        return redirect()->back();
    }

}