<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    {{-- link boostrap --}}
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

    <title>Welcome</title>

    {{-- css --}}
    <style>
        *{
            margin: 0px;
            padding: 0px;
            box-sizing: border-box;
            font-family: 'poppins', sans-serif;
        }

        body {
            background-image: linear-gradient(90deg, #0d45ac 0%, #8f2a7e 100%);
        }
        
        span {
            color: white;
            text-shadow: 0 4px 30px rgb(46, 9, 34);
        }

        .btn {
            text-decoration: none;
            font-size: 30px;
            background-image: linear-gradient(90deg, #0059ff 0%, #ff04d5 100%);
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
            color: white;
            padding: 10px 10px;
            border-radius: 30px;
            border: none;
            justify-content: center;
            width: 70%;
            transition: transform 0.3s ease-in-out;
        }

        .btn:hover {
            background: linear-gradient(90deg, #b7cffd 0%, #f8b1ed 100%);
            text-decoration: none;
            transform: scale(1.05);
        }

        .container-all {
            display: flex;
            flex-direction: row;
            align-items: center;
            padding: 40px 90px;
        }

        .container img {
            width: 80%;
            height: 70%;
            overflow: hidden;
            transition: transform 0.3s ease-in-out;
        }

        .container img:hover{
            transform: scale(1.05);
        }
    </style>
</head>
<body>
    {{-- penghubung ke view navbar --}}
    @include('navbar')

    <div class="container-all">

        <div class="container">
            {{-- kata kata tulisan welcome --}}
            <div class="text-white h1" style="font-size: 70px"><span><b>Welcome to</b></span></div>
            <div class="text-white h1" style="font-size: 60px"><span><b>Softengine Gallery</b></span></div>
            <div class="text-white" style="font-size: 30px;"><p>a place where there are millions of</p></div>
            <div class="text-white" style="font-size: 30px;"><p>photos from all over the world</p></div>
            {{-- button regist --}}
            <a href="/regist"><button type="submit" class="btn">Daftar Sekarang!</button></a>
        </div>

        {{-- foto welcome --}}
        <div class="container">
            <center><img src="image/welcome_image.png"></center>
        </div>
    </div>

    {{-- link fontawesome --}}
    <script src="https://kit.fontawesome.com/fab5be3424.js" crossorigin="anonymous"></script>
</body>
</html>