<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    {{-- bootstrap link --}}
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    
    <title>Komentar</title>

    {{-- css --}}
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('image/bg.png');
            background-size: cover;
            background-position: center;
        }

        .comment-container {
            margin: 20px auto;
            border-radius: 20px;
            width: 40%;
            height: 20%;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.767);
            display: flex;
            flex-direction: column;
            align-items: left;
        }

        .card-body {
            padding: 5px 30px 30px 30px;
            max-width: 100%;
        }

        .comment-container img {
            width: 100%;
            height: 30%;
            border-radius: 20px;
        }

        .like-container {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
        }

        .like-button {
            margin-right: 10px;
        }

        .comment {
            border: none;
            padding: 10px;
            margin-bottom: 10px;
        }

        .comment-form {
            margin-top: 20px;
            display: flex;
            align-items: center;
        }

        .comment-input {
            width: 80%;
            padding: 8px;
            border-radius: 20px;
            border-color: #3000df;
        }

        .comment-button {
            padding: 8px 12px;
            width: 80px;
            background-color: #3000df;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin: 0px 0px 0px 20px;
        }
    </style>
</head>
<body>
    {{-- navbar --}}
    @include ('navbar')

        {{-- button kembali ke halaman sebelumnya --}}
        <div class="d-flex flex-row" style="width: 70px; margin: 30px 0px 0px 30px;">
            <a href="{{ url()->previous() }}" class="btn btn-primary fa fa-chevron-left" style="background-image: linear-gradient(90deg, #0059ff 0%, #ff04d5 100%); border: none;"></a>
        </div>

    <div class="comment-container">
        {{-- view foto --}}
        <img src="{{Storage::url($foto->LokasiFile)}}" class="card-img-top">
        <div class="card-body">
            {{-- atribut foto --}}
            <h1><b>{{ $foto ->JudulFoto }}</b></h1>
            <p>{{ $foto->DeskripsiFoto }}</p>
                @php
                $user = \App\Models\User::find($foto->UserID);
                @endphp
            <b>{{ $user->Username }}</b>
            <p>{{ $foto->TanggalUnggah }}</p>
    
            {{-- like --}}
            <div class="like-container">
                @if ($cek = $likee->where('UserID', session('user')->UserID)->where('FotoID', $foto->FotoID)->first())
                    <a href="/likee/{{$foto->FotoID}}" class="like-button">
                        <i class="fa-solid fa-heart" style="font-size: 20px; color: red;"></i>
                    </a>
                @else
                {{-- dislike --}}
                    <a href="/likee/{{$foto->FotoID}}" class="like-button">
                        <i class="fa-regular fa-heart" style="font-size: 20px; color: red;"></i>
                    </a>
                @endif
                {{-- jumlah like --}}
                <p style="margin: 0 10px 0 0;">{{ $likee->where('FotoID', $foto->FotoID)->count() }}</p>
            </div>
    
            {{-- input komentar --}}
            <form action="/berikomen/{{$foto->FotoID}}" method="POST" class="comment-form">
                @csrf
                <input type="text" name="isi" class="comment-input" required autofocus placeholder="Tambahkan komentar..." >
                <button type="submit" class="comment-button">Kirim</button>
            </form>
            {{-- view komentar --}}
            @foreach ($komen as $kmn)
                <div class="comment">
                    @php
                        $user = \App\Models\User::find($foto->UserID);
                    @endphp
                    <b>{{ $user->Username }}:</b> {{$kmn->IsiKomentar}}
                </div>
            @endforeach
        </div>
    </div>
    

    {{-- fontawesome --}}
    <script src="https://kit.fontawesome.com/fab5be3424.js" crossorigin="anonymous"></script>
</body>
</html>
