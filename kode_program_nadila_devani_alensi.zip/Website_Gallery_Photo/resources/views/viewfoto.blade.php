<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    {{-- link fontawesome --}}
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

    <title>Card View Foto</title>
    {{-- css --}}
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background-image: url('/image/bg.png');
            background-size: cover;
        }

        .container {
            max-width: 90%;
            margin: 0 auto;
            padding: 0px 0;
        }

        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 10px;
        }

        .btn {
            text-decoration: none;
            display: inline-block;
            font-size: 20px;
            background-image: linear-gradient(90deg, #0059ff 0%, #ff04d5 100%);
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
            color: white;
            padding: 10px 20px;
            border-radius: 30px;
            border: none;
            margin: 20px 0 10px;
            justify-content: center;
            align-items: center;
            width: 250px;
        }

        .btn:hover {
            background: linear-gradient(90deg, #b7cffd 0%, #f8b1ed 100%);
            text-decoration: none;
            color: #3100e2;
        }

        .card {
            width: 19rem;
            margin-bottom: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.767);
            transition: transform 0.3s ease-in-out;
        }

        .card:hover {
            transform: scale(1.05);
        }

        .card-img-top {
            width: 100%;
            height: auto;
        }

        .btn-like {
            display: inline-block;
            padding: 5px;
            font-size: 20px;
            width: 45px;
            text-align: center;
            text-decoration: none;
            border: none;
            border-radius: 10px;
            color: white;
            background-color: #ff0000;
            transition: background-color 0.3s ease;
        }

        .btn-like:hover {
            background-color: #ffffff; /* Warna latar belakang saat tombol dihover */
            color: #e60000; /* Warna teks saat tombol dihover */
        }

            .btn-comment {
        display: inline-block;
        padding: 5px;
        font-size: 20px;
        width: 45px;
        text-align: center;
        text-decoration: none;
        border: none;
        border-radius: 10px;
        color: white;
        background-color: #0099ff;
        transition: background-color 0.3s ease;
        }

        .btn-comment:hover {
            background-color: #ffffff; /* Warna latar belakang saat tombol dihover */
            color: #0099ff; /* Warna teks saat tombol dihover */
        }

        .delete {
            border: none;
            background: none;
            outline: none;
            color: rgba(0, 0, 0, 0.767);
        }

    </style>
</head>

<body>
    {{-- penghubung ke view navbar --}}
    @include('navbar')

    {{-- judul view --}}
    <div style="color: #3100e2; text-shadow: 0 4px 30px rgb(255, 255, 255);">
        <br>
        <center><h1><b>My Photo</b></h1></center>
    </div>
    <br>

    {{-- btn upload foto baru --}}
    <div class="text-center">
        <a href="/tambahfoto"><input type="submit" value="Upload Foto" class="btn btn-primary"></a>
    </div>

    <div class="container mt-4">
        {{-- button kembali ke halaman sebelumnya --}}
        <div class="d-flex flex-row" style="width: 70px;">
            <a href="{{ url()->previous() }}" class="btn btn-primary fa fa-chevron-left"></a>
        </div>

        {{-- view foto  --}}
        <div class="grid">
            @foreach ($foto as $foto) {{--perulangan view foto--}}
                <div class="card" style="width: 18rem; text-align: left;">
                    {{-- foto --}}
                    <img src="{{Storage::url($foto->LokasiFile)}}" class="card-img-top">

                    <div class="card-body">
                        {{-- atribut foto --}}
                        <h3 class="card-title"><b>{{ $foto ->JudulFoto }}</b></h3>
                        <p class="card-text my-1">{{ $foto ->DeskripsiFoto }}</p>
                        <p class="card-text my-1">
                            @php
                                $user = \App\Models\User::find($foto->UserID);
                            @endphp
                            <b>{{ $user->Username }}</b>
                        </p>
                        <p class="card-text my-1">{{ $foto->TanggalUnggah }}</p>

                        {{-- btn like --}}
                        <div class="d-flex flex-row">
                            @if ($cek = $likee->where('UserID', session('user')->UserID)->where('FotoID', $foto->FotoID)->first())
                            {{-- like --}}
                            <a href="/likee/{{$foto->FotoID}}">
                                <i class="fa-solid fa-heart" style="font-size: 30px; color: red;"></i>
                            </a>
                            <p style="padding: 0px 20px 0px 0px;">{{ $likee->where('FotoID', $foto->FotoID)->count() }}</p>
                            @else
                            {{-- dislike --}}
                            <a href="/likee/{{$foto->FotoID}}" style="padding: 0px 20px 0px 0px;">
                                <i class="fa-regular fa-heart" style="font-size: 30px; color: red;"></i>
                            </a>
                            @endif

                            {{-- btn komentar --}}
                            <a href="/komene/{{$foto->FotoID}}">
                                <i class="fa-solid fa-message" style="font-size: 30px;"></i>
                            </a>

                            {{-- hapus foto --}}
                            <form action="{{ route('hapusFoto', ['FotoID' => $foto->FotoID]) }}" method="POST">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="delete" onclick="return confirm('Apakah Anda yakin ingin menghapus foto ini?')" style>
                                    <i class="fas fa-trash-alt" style="font-size: 20px; padding: 0px 0px 0px 20px;"></i>
                                </button>
                            </form>
                            
                            
                            
                            
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>

    {{-- link fontawesome --}}
    <script src="https://kit.fontawesome.com/fab5be3424.js" crossorigin="anonymous"></script>
    
</body>
</html>
