<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    {{-- link bootstrap --}}
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    
        <title>My Gallery</title>

    {{-- css --}}
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background-image: url('/image/bg.png');
            background-size: cover;
        }

        .container {
            max-width: 90%;
            margin: 0 auto;
            padding: 0px 0;
        }

        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 10px;
        }

        .btn {
            text-decoration: none;
            display: inline-block;
            font-size: 20px;
            background-image: linear-gradient(90deg, #0059ff 0%, #ff04d5 100%);
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
            color: white;
            padding: 10px 20px;
            border-radius: 30px;
            border: none;
            margin: 20px 0 10px;
            justify-content: center;
            align-items: center;
            width: 250px;
        }

        .btn:hover {
            background: linear-gradient(90deg, #b7cffd 0%, #f8b1ed 100%);
            text-decoration: none;
            color: #3100e2;
        }

        .card {
            width: 15rem;
              margin-bottom: 15px; /* Adds some space below each card */
              box-shadow: 0 4px 8px rgba(0, 0, 0, 0.767);
            transition: transform 0.3s ease-in-out;
        }

        .card:hover {
            transform: scale(1.05);
        }

        .card-img-top {
            width: 100%;
            height: auto;
            border-radius: 20%;
        }

        
        .delete {
            border: none;
            background: none;
            outline: none;
            color: rgba(0, 0, 0, 0.767); /* Ganti dengan warna sesuai kebutuhan */
        }

    </style>
</head>
<body>
    {{-- penghubung ke view navbar --}}
    @include('navbar')

    <div class="text-center mx-2 mx-lg-1" style="margin-top: 20px;">
        <br>
        {{-- nama user pemilik album --}}
        <a class="nav-link" aria-disabled="true" href="#!" style="color: #3100e2; font-size: 25px;">
            <div>
                <i class="fa fa-user fa-lg mb-1" style="font-size: 50px;"></i>
            </div>
            @if(session('user'))
                <b>{{ session('user')->Username }}</b>
            @else
                Profile
            @endif
        </a>
        <br>
    </div>

    {{-- judul view album --}}
    <div style="color: #3100e2; text-shadow: 0 4px 30px rgb(255, 255, 255);">
        <center><h1><b>My Gallery Album</b></h1></center>
    </div>

    {{-- btn buat album baru --}}
    <div class="text-center">
        <a href="/buatalbum"><input type="submit" value="Create new album" class="btn btn-primary"></a>
    </div>

    {{-- view album --}}
    <div class="container mt-4">
        {{-- button kembali ke halaman sebelumnya --}}
        <div class="d-flex flex-row" style="width: 70px;">
            <a href="{{ url()->previous() }}" class="btn btn-primary fa fa-chevron-left"></a>
        </div>

        <div class="grid">
            {{-- perulangan album --}}
            @foreach ($album as $album)
                {{-- menampilkan album milik user yg sedang login --}}
                @if (session()->get('user')->UserID == $album->UserID)
                    {{-- apabila card di clik akan beralih ke view album yg berisi fotonya --}}
                    <a href="/viewfoto/{{$album->AlbumID}}">
                        <div class="card" style="width: 18rem; text-align: left;">
                            {{-- view foto album pelengkap --}}
                            <img src="image/album_image.png" class="card-img-top">
                            {{-- atribut album --}}
                            <div class="card-body">
                                <h5 class="card-title" style="margin-bottom: 0;"><b>{{ $album->NamaAlbum }}</b></h5>
                                <p class="card-text">{{ $album->Deskripsi }}</p>
                                <p class="card-text">{{ $album->TanggalDibuat }}</p>
                            </div>

                            {{-- hapus album --}}
                            <center>
                            <form action="{{ route('hapusAlbum', ['AlbumID' => $album->AlbumID]) }}" method="POST">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="delete" onclick="return confirm('Apakah Anda yakin ingin menghapus album ini?')">
                                    <i class="fas fa-trash-alt" style="font-size: 20px; padding: 10px;"></i>
                                </button>
                            </form>
                            </center>
                        </div>
                    </a>
                @endif
            @endforeach
        </div>
    </div>

    {{-- link fontawesome --}}
    <script src="https://kit.fontawesome.com/fab5be3424.js" crossorigin="anonymous"></script>
</body>
</html>
