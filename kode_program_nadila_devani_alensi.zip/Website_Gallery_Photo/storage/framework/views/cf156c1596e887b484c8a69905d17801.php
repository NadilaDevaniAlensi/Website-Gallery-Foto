<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

    <title>Login</title>

    <style>
        *{
            margin: 0px;
            padding: 0px;
            box-sizing: border-box;
            font-family: 'poppins', sans-serif;
        }

        body {
            background-image: linear-gradient(90deg, #0d45ac 0%, #8f2a7e 100%);
        }
        
        span {
            color: rgb(90, 0, 207);
            text-shadow: 0 4px 30px rgb(255, 255, 255);
        }

        .card {
            text-decoration: none;
            border: none;
            border-radius: 40px;
            width: 90%;
            height: 80%;
            color: white;
            padding: 30px 30px;
            background:rgba(255, 255, 255, 0.281);
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
        }

        .btn {
            text-decoration: none;
            display: inline-block;
            font-size: 30px;
            font-weight: 500px;
            background-image: linear-gradient(90deg, #0059ff 0%, #ff04d5 100%);
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
            color: white;
            padding: 10px 10px;
            border-radius: 30px;
            border: none;
            margin: 20px 0 5px;
            justify-content: center;
            align-items: center;
            width: 70%;
            overflow: hidden;
            transition: transform 0.3s ease-in-out;
        }

        .btn:hover {
            background: linear-gradient(90deg, #b7cffd 0%, #f8b1ed 100%);
            text-decoration: none;
            color: #3100e2;
            transform: scale(1.05);
        }

        .container-2 {
            display: flex;
            flex-direction: row;
            justify-content: center;
            align-items: center;
            padding: 0px 100px;
        }

        .container img {
            width: 100%;
            height: 90%;
            overflow: hidden;
            transition: transform 0.3s ease-in-out;
        }

        .container img:hover{
            transform: scale(1.05);
        }
    </style>
</head>
<body>
    
    <?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container-2">
        
        <div class="container">
            <img src="<?php echo e(url('image/login_image.png')); ?>">
        </div>
        
        <div class="container d-flex justify-content-center">
            <div class="card shadow-lg" data-tilt>
                <main class="form-registration">
                    
                    <center>
                    <h1 class="mb-8 fw-normal text-center mt-8"><span><b>LOGIN</b></span></h1>
                    <p>Hello! Welcome back to Softengine Gallery</p>
                    </center>

                    
                    <div class="card-body mt-7">
                        <form action="/login" method="POST">
                            
                            <center><p style="color: rgb(255, 35, 35)"><?php echo e(session()->get('pesan')); ?></p></center> 
                            
                            <?php echo csrf_field(); ?>
                            <div class="form mt-3">
                                <input type="text" name="Username" placeholder="Username"
                                class="form-control py-2 mt-0"
                                style="background-color: rgba(255, 255, 255, 0.377); border-radius: 50px;">
                            </div>
                            <div class="form mt-3">
                                <input type="password" name="Password" placeholder="Password"
                                class="form-control py-2 mt-0"
                                style="background-color: rgba(255, 255, 255, 0.377); border-radius: 50px;">
                            </div>

                            <div>
                                
                                <center class="mt-4">
                                    
                                    <p>Belum punya akun? <a href="/regist">Daftar</a> sekarang!</p>
                                    
                                    <input type="submit" value="Masuk" class="btn">
                                </center>
                            </div>
                        </form>
                    </div>
                </main>
            </div>
        </div>
    </div>

    
    <script src="https://kit.fontawesome.com/fab5be3424.js" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH C:\Laravel\Website_Gallery_Photo\resources\views/login.blade.php ENDPATH**/ ?>