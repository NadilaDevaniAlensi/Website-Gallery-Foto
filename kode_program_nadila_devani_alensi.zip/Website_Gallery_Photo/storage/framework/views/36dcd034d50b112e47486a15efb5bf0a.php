<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    <title>navbar</title>
    
    <style>
      *{
        margin: 0px;
        padding: 0px;
        box-sizing: border-box;
        font-family: 'poppins', sans-serif;
      }

      .navbar {
        max-height: 70px;
          
      }

      .btn {
            padding: .45rem 1.5rem .35rem;
      }

      .nav-item {
            font-size:  13px;
      }

      .nav-link:hover {
          color: #ffffff;
      }

      .nav-item2 {
          overflow: hidden;
          transition: transform 0.3s ease-in-out;
      }

      .nav-item2:hover {
          transform: scale(1.05);
      }
        
      .gradient-custom {
        /* backgorun colornya */
            /* fallback for old browsers */
            background: #c471f5;

            /* Chrome 10-25, Safari 5.1-6 */
            background-image: linear-gradient(90deg, #0059ff 0%, #ff04d5 100%);
            /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
            background-image: linear-gradient(90deg, #0059ff 0%, #ff04d5 100%);
      }
        
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark gradient-custom">
      <div class="container-fluid">
        
        
        <div class="navbar-brand fs-4">
            <img src="image/logo.png" style="width: 60px; height:45px; margin:10px;">
        </div>
        
        <p class="navbar-brand" style="font-size: 25px; padding: 0px 40px 0px 0px;">Softengine Gallery</p>


    <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <?php if(session('user') == !null): ?>
        <!-- Left links -->
        <ul class="navbar-nav me-auto d-flex flex-row mt-3 mt-lg-0">
        
        
        
        <li class="nav-item text-center mx-2 mx-lg-1">
          <a class="nav-link" aria-current="page" href="/home">
            <div>
              <i class="fas fa-home fa-lg mb-1"></i>
            </div>
            Home
          </a>
        </li>
        
        <li class="nav-item text-center mx-2 mx-lg-1">
          <a class="nav-link" href="tambahfoto">
            <div>
              <i class="fas fa-image fa-lg mb-1"></i>
            </div>
            Upload Foto
          </a>
        </li>
        
        <li class="nav-item text-center mx-2 mx-lg-1">
            <a class="nav-link" href="/buatalbum">
              <div>
                <i class="fa fa-folder-open-o fa-lg mb-1"></i>
              </div>
              Buat Album
            </a>
        </li>
        
        <li class="nav-item text-center mx-2 mx-lg-1">
            <a class="nav-link" href="/viewalbum">
              <div>
                <i class="far fa-folder fa-lg mb-1"></i>
              </div>
              My Album
            </a>
        </li>
        
        <li class="nav-item text-center mx-2 mx-lg-1" style="padding: 0px 450px 0px 0px;">
            <a class="nav-link" aria-disabled="true" href="#">
                <div>
                    <i class="fa fa-user fa-lg mb-1"></i>
                </div>
                
                <?php if(session('user')): ?>
                    <?php echo e(session('user')->Username); ?>

                <?php else: ?>
                    Profile
                <?php endif; ?>
            </a>
        </li>
    <?php endif; ?>
      <!-- Left links -->

      <!-- Right links -->
      <ul class="navbar-nav ms-auto d-flex flex-row mt-3 mt-lg-0">
        <li class="nav-item2 text-center mx-2 mx-lg-1">
          
            <?php if(session('user') == !null): ?>
            <a href ="/logout" class=" nav-item2 text-white text-decoration-none px-3 py-2 rounded-4 " style="background-color: #ae00ff; border: none; border-radius: 20px; font-size: 15px;"><i class="fa fa-sign-out fa-lg"></i><b>  Logout</b></a>
            <?php else: ?>
            <a href ="/login" class="text-white text-decoration-none px-3 py-1 rounded-4" style="font-size: 18px;"><b>Login</b></a>
            <?php endif; ?>
        </li>

        
        <li class="nav-item2 text-center mx-2 mx-lg-1">
            <?php if(session('user')): ?>
            <?php else: ?>
            <a href ="/regist" class="text-white text-decoration-none px-3 py-1 rounded-4" style="background-color: #ae00ff; border: none; border-radius: 20px; margin: 10px; padding: 20px; font-size: 18px;"><b>Daftar</b></a>
            <?php endif; ?>
        </li>
      </ul>
      <!-- Right links -->

    </div>
  </div>
</nav>
<!-- Navbar -->

    
    <script src="https://kit.fontawesome.com/fab5be3424.js" crossorigin="anonymous"></script>
    <script src="/path/to/bootstrap/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html><?php /**PATH C:\Laravel\Website_Gallery_Photo\resources\views/navbar.blade.php ENDPATH**/ ?>