<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

        <title>Upload Foto</title>
    
    
    <style>
        *{
            margin: 0px;
            padding: 0px;
            box-sizing: border-box;
            font-family: 'poppins', sans-serif;
        }

        body {
            background-image: linear-gradient(90deg, #0d45ac 0%, #8f2a7e 100%);
        }
        
        .h1 {
            color: rgb(90, 0, 207);
            text-shadow: 0 4px 30px rgb(255, 255, 255);
        }

        .card {
            text-decoration: none;
            border: none;
            border-radius: 20px;
            width: 60%;
            height: 50%;
            color: white;
            padding: 0px 30px;
            margin: 20px;
            background:rgba(255, 255, 255, 0.281);
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
        }

        .form-control {

            border-radius: 20px;
            color: white;
            background:rgba(255, 255, 255, 0.281);
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
        }

        .btn {
            text-decoration: none;
            display: inline-block;
            font-size: 30px;
            font-weight: 500px;
            background-image: linear-gradient(90deg, #0059ff 0%, #ff04d5 100%);
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
            color: white;
            border-radius: 30px;
            border: none;
            justify-content: center;
            align-items: center;
            width: 50%;
            overflow: hidden;
            transition: transform 0.3s ease-in-out;
        }

        .btn:hover {
            background: linear-gradient(90deg, #b7cffd 0%, #f8b1ed 100%);
            text-decoration: none;
            color: #3100e2;
            transform: scale(1.05);
        }

    </style>
</head>

<body>
    
    <?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <div class="container-2 ">
        
        <div class="container d-flex justify-content-center">
            <div class="card shadow-lg" data-tilt>
                <main class="form-up">
                    <br>
                    
                    <h1 class="h1 text-center"><b>Upload Foto</b></h1>
                    <center><p>Upload your photo now</p></center>

                    
                    <div class="card-body">
                        <form action="/fotoAksiCoyyy" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="text" name="JudulFoto" placeholder="Judul Foto" class="form-control my-1 py-2 custom-input">
                            <input type="text" name="DeskripsiFoto" placeholder="DeskripsiFoto" class="form-control my-3 py-2 custom-input">
                            <input type="file" name="LokasiFile" placeholder="Lokasi File" class="form-control my-3 py-2 custom-input">
                            
                            <select name="album" class="form-control my-3 py-2 custom-input">
                                <option value="">Pilih Album</option>
                                <?php $__currentLoopData = $album; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->AlbumID); ?>"><?php echo e($item->NamaAlbum); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                            
                            <div class="text-center my-4">
                                <input type="submit" value="Upload" class="btn btn-primary">
                            </div>
                        </form>     
                    </div>
                </main>
            </div>
        </div>
    </div>

    
    
    <script src="https://kit.fontawesome.com/fab5be3424.js" crossorigin="anonymous"></script>
</body>

</html>
<?php /**PATH C:\Laravel\Website_Gallery_Photo\resources\views/tambahfoto.blade.php ENDPATH**/ ?>