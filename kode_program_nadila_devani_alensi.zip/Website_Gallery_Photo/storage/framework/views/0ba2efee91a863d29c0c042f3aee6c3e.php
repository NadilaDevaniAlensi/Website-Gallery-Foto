<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

        <title>Home</title>

    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'poppins', sans-serif;
        }

        body {
            background-color:#ffffff;
            background-size: cover;
            background-position: center;
        }

        span {
            color: #ffffff;
            text-shadow: 0 4px 30px rgb(46, 9, 34);
        }

        .btn {
            text-decoration: none;
            display: inline-block;
            font-size: 20px;
            background-image: linear-gradient(90deg, #0059ff 0%, #ff04d5 100%);
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
            color: #fff;
            padding: 10px 10px;
            border-radius: 30px;
            justify-content: center;
            max-width: 400px;
            border: none;
            
        }
        
        .btn:hover {
            background: linear-gradient(90deg, #b7cffd 0%, #f8b1ed 100%);
            text-decoration: none;
            color: #3100e2; 
        }

        .banner {
          background-image: url('image/banner_home.png');
          background-size: cover;
        }

        .photo-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(18rem, 1fr));
            gap: 20px;
            justify-content: center;
        }

        .card {
            border: 1px solid #ddd;
            border-radius: 8px; /* Mengurangi border radius */
            overflow: hidden;
            transition: transform 0.3s ease-in-out;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); /* Mengurangi box-shadow */
        }

        .card:hover {
            transform: scale(1.05);
        }

        .card-img-top {
            height: 200px; /* Mengurangi tinggi gambar */
            object-fit: cover;
        }

        .card-body {
            padding: 10px;
            font-size: 14px;
        }

        .fa-heart,
        .fa-message {
            margin-right: 5px;
            color: #008cff;
            transition: color 0.3s ease-in-out;
        }

        .fa-heart:hover,
        .fa-message:hover {
            color: #85b5fd;
        }


        /* css untuk scrollbar album /seluruhnya */
        /* Untuk browser berbasis WebKit (Chrome, Safari, dll.) */
        ::-webkit-scrollbar {
            width: 10px;
        }

        ::-webkit-scrollbar-thumb {
            background-image: linear-gradient(90deg, #72a3fd 0%, #f87de4  100%);
            border-radius: 6px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background-image: linear-gradient(90deg, #013391 0%, #ff00d4  100%);
        }

        ::-webkit-scrollbar-track {
            background-color: rgb(211, 209, 209);
            border-radius: 20PX;
        }

    </style>
</head>

<body>
  
  <?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
<div class="container-fluid">
<div class="px-lg-5">


    <div class="row py-5">
      <div class="col-lg-0 mx-auto">
        <div class="text-white p-5 shadow-sm rounded banner">
          <h1 class="display-4">Selamat Datang, 
                <?php if(session('user')): ?>
                    <?php echo e(session('user')->Username); ?>

                <?php else: ?>
                    My Profile
                <?php endif; ?> !
            </h1>
          <p class="lead">Website Gallery Photo SMK Bukit Asam</p>
          <p class="lead">all about history of SMK BA, Images by XII RPL</a>.
          </p>
        </div>
      </div>
    </div>
    
<!--album Foto -->
    
    <div style="color: #3100e2; text-shadow: 0 4px 30px rgb(255, 255, 255); ">
        <center><h2><b>Album</b></h2></center>
    </div>
    <div style="overflow-x: auto;">
        <ul class="list-unstyled">
            <li class="kategori d-flex flex-row">
              
                <?php $__currentLoopData = $album; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                  <a href="/viewfoto/<?php echo e($album->AlbumID); ?>">
                    <div class="btn" style="width: 13rem; text-align: center; margin-right: 10px;">
                      <h5 class="card-title" style="margin-bottom: 0;"><?php echo e($album->NamaAlbum); ?></h5>
                    </div>
                  </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </li>
        </ul>
    </div>

<br>
<br>
  

    
    <div style="color: #3100e2; text-shadow: 0 4px 30px rgb(255, 255, 255); ">
      <center><h2><b>Photo</b></h2></center>
    </div>

    <div class="row">
        <div class="photo-grid">

          
          <?php $__currentLoopData = $foto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
          <div class="card" style="width: 18rem; text-align: left;">
              
              <img src="<?php echo e(Storage::url($foto->LokasiFile)); ?>" class="card-img-top">

              <div class="card-body">
                  
                  <h3 class="card-title" style="font-size: 1.2rem;"><b><?php echo e($foto ->JudulFoto); ?></b></h3>
                  <p class="card-text my-1"><?php echo e($foto->DeskripsiFoto); ?></p>
                  <p class="card-text my-1">
                      <?php
                          $user = \App\Models\User::find($foto->UserID);
                      ?>
                      <b><?php echo e($user->Username); ?></b>
                  </p>
                  <p class="card-text my-1"><?php echo e($foto->TanggalUnggah); ?></p>

                  
                  <div class="d-flex flex-row">
                      <?php if($cek = $likee->where('UserID', session('user')->UserID)->where('FotoID', $foto->FotoID)->first()): ?>
                      
                      <a href="/likee/<?php echo e($foto->FotoID); ?>">
                          <i class="fa-solid fa-heart" style="font-size: 30px; color: red;"></i>
                      </a>
                      <p style="padding: 0px 20px 0px 0px;"><?php echo e($likee->where('FotoID', $foto->FotoID)->count()); ?></p>
                      <?php else: ?>
                      
                      <a href="/likee/<?php echo e($foto->FotoID); ?>" style="padding: 0px 20px 0px 0px;">
                          <i class="fa-regular fa-heart" style="font-size: 30px; color: red;"></i>
                      </a>
                      <?php endif; ?>

                      
                      <a href="/komene/<?php echo e($foto->FotoID); ?>">
                          <i class="fa-solid fa-message" style="font-size: 30px;"></i>
                      </a>
                  </div>
              </div>
          </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-De6QBWenF9k2x0Sc32fwImT9E6C7q2hd5ucHbD10xzEQ7jwI0p5LzRYj2QIDBbfa" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.5.3/dist/js/bootstrap.min.js" integrity="sha384-GLhlTQ8iKbVR1pZI4JiR4NqUHYENAt5IBqVc2Xg3E1UC2C1qOsL+59uRB1U5+8U/" crossorigin="anonymous"></script>

    
    <script src="https://kit.fontawesome.com/fab5be3424.js" crossorigin="anonymous"></script>
</body>

</html>

<?php /**PATH C:\Laravel\Website_Gallery_Photo\resources\views/home.blade.php ENDPATH**/ ?>