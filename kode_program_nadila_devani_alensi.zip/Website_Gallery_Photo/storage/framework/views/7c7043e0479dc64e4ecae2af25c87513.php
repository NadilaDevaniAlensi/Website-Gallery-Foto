<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    
        <title>Buat Album</title>

    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'poppins', sans-serif;
        }

        body {
            background-image: linear-gradient(90deg, #0d45ac 0%, #8f2a7e 100%);
        }

        .text {
            font-family: 'Montserrat';
            font-size: 35.6px;
        }

        span {
            color: #f14cdb;
        }

        .card {
            width: 80%;
            height: 50%;
            max-width: 1600px;
            color: #fff;
            padding: 3px 30px;
            border: 1px solid rgba(255, 255, 255, 0.3);
            background: rgba(255, 255, 255, 0.2);
            border-radius: 30px;
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
        }

        .card h1 {
            color: rgb(46, 3, 201);
            font-size: 40px;
            margin-top: 0px;
        }

        .btn {
            text-decoration: none;
            display: inline-block;
            font-size: 25px;
            font-weight: 500;
            background-image: linear-gradient(90deg, #0059ff 0%, #ff04d5 100%);
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
            color: #fff;
            padding: 10px 30px;
            border-radius: 30px;
            margin: 10px 0 20px;
            justify-content: center;
            align-items: center;
            width: 100%;
            max-width: 440px; 
        }

        .btn:hover {
            background: linear-gradient(90deg, #b7cffd 0%, #f8b1ed 100%);
            text-decoration: none;
            color: #3100e2;
        }

        .container-2 {
            display: flex;
            flex-direction: row;
            justify-content: center;
            align-items: center;
            padding: 20px 40px;
        }

        .container img {
            width: 80%;
            height: 70%;
        }

    </style>
</head>

<body>
    
    <?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <div class="container-2 ">
        <div class="container d-flex justify-content-center">
            <div class="card shadow-lg flex-lg-row" data-tilt>

                    
                    <div style="width: 60%; height: 70%; padding: 50px 10px;">
                        <img src="<?php echo e(url('image/album_image.png')); ?>" alt="Image"/>
                    </div>
                    <main class="form-album">
                        <br>
                        <div>
                                                        
                            <h1 class="h1 mb-9 fw-normal text-center mt-10"><b>Create New Album</b></h1>
                            <center><p>Create your amazing album now</p></center>
                        </div>

                        
                        <div class="card-body">
                            <form action="/album" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form mt-1">
                                    <p for="NamaAlbum" class="form-label">&emsp;Nama Album</p>
                                    <input type="text" name="NamaAlbum"
                                    class="form-control py-2 mt-1"  id="NamaAlbum"
                                    style="background-color: rgba(255, 255, 255, 0.377) ; border-radius: 25px;">
                                </div>
                                <div class="form mt-2">
                                    <p for="DeskripsiAlbum" class="form-label">&emsp;Deskripsi Album</p>
                                    <input type="textarea" name="Deskripsi"
                                    class="form-control py-2 mt-1"  id="DeskripsiAlbum"
                                    style="background-color: rgba(255, 255, 255, 0.377) ; border-radius: 25px;">
                                </div>
                                <div>
                                    
                                    <center class="mt-8">
                                        <br>
                                        <br>
                                        <button type="submit" class="btn">Create</button>
                                    </center>      
                                </div>
                            </form>
                        </div>
                    </main>
                </ul>
            </div>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\Laravel\Website_Gallery_Photo\resources\views/buatalbum.blade.php ENDPATH**/ ?>