<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <!-- resources/views/editalbum.blade.php -->


<?php $__env->startSection('content'); ?>
    <h2>Edit Album</h2>
    <form action="<?php echo e(route('editalbum', ['AlbumID' => $album->AlbumID])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <!-- Tambahkan input untuk nama album dan deskripsi album -->
        <label for="NamaAlbum">Nama Album:</label>
        <input type="text" name="NamaAlbum" value="<?php echo e($album->NamaAlbum); ?>" required>

        <label for="Deskripsi">Deskripsi Album:</label>
        <textarea name="Deskripsi" required><?php echo e($album->Deskripsi); ?></textarea>

        <button type="submit">Simpan Perubahan</button>
    </form>
<?php $__env->stopSection(); ?>

</body>
</html>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\Website_Gallery_Photo\resources\views/editalbum.blade.php ENDPATH**/ ?>